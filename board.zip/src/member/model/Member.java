package member.model;

import java.util.Date;

public class Member {

	private String user_id;
	private String user_pwd;	
	private String user_name;
	private String user_birth;
	private String user_addr;
	private String user_tel;
	private String adm_check = "0";
	
	public Member(String user_id, String user_pwd, String user_name, String user_birth, String user_addr, String user_tel, String adm_check) {
		this.user_id = user_id;
		this.user_pwd = user_pwd;
		this.user_name = user_name;
		this.user_birth = user_birth;
		this.user_addr = user_addr;
		this.user_tel = user_tel;
		this.adm_check = adm_check;
	}
	
	public String getUser_id() {
		return user_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public String getUser_birth() {
		return user_birth;
	}

	public String getUser_addr() {
		return user_addr;
	}

	public String getUser_tel() {
		return user_tel;
	}

	public String getAdm_check() {
		return adm_check;
	}

	public String getUser_pwd() {
		return user_pwd;
	}

	public boolean matchPassword(String user_pwd) {
		return user_pwd.equals(user_pwd);
	}

	public void changePassword(String newPwd) {
		this.user_pwd = newPwd;
	}

}
