package member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import jdbc.JdbcUtil;
import member.model.Member;

public class MemberDao {

	public Member selectById(Connection conn, String id) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(
					"select * from user_tbl where user_id = ?");
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			Member member = null;
			if (rs.next()) {
				member = new Member(
						rs.getString("user_id"), 
						rs.getString("user_pwd"), 
						rs.getString("user_name"),
						rs.getString("user_birth"),
						rs.getString("user_addr"),
						rs.getString("user_tel"),
						rs.getString("adm_check"));
			}
			return member;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	public void insert(Connection conn, Member mem) throws SQLException {
		try (PreparedStatement pstmt = 
				conn.prepareStatement("insert into user_tbl values(?,?,?,?,?,?,?)")) {
			pstmt.setString(1, mem.getUser_id());
			pstmt.setString(2, mem.getUser_pwd());
			pstmt.setString(3, mem.getUser_name());
			pstmt.setString(4, mem.getUser_birth());
			pstmt.setString(5, mem.getUser_addr());
			pstmt.setString(6, mem.getUser_tel());
			pstmt.setString(7, mem.getAdm_check());
			
			pstmt.executeUpdate();
		}
	}

	public void update(Connection conn, Member member) throws SQLException {
		try (PreparedStatement pstmt = conn.prepareStatement(
				"update user_tbl set user_pwd = ?, user_name = ?, "
				+" user_birth = ?, user_addr = ?, user_tel = ? "
				+" where user_id = ?")) {
			
			pstmt.setString(1, member.getUser_pwd());
			pstmt.setString(2, member.getUser_name());
			pstmt.setString(3, member.getUser_birth());
			pstmt.setString(4, member.getUser_addr());
			pstmt.setString(5, member.getUser_tel());
			pstmt.setString(6, member.getUser_id());
			
			pstmt.executeUpdate();
		}
	}
}
