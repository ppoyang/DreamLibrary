package history.service;

import history.model.BookName;
import history.model.Rent;

public class HistoryData {

	private Rent rent;
	private BookName bookName;
	
	public HistoryData(Rent rent, BookName bookName) {
		this.rent = rent;
		this.bookName = bookName;
	}

	public Rent getRent() {
		return rent;
	}

	public BookName getBookName() {
		return bookName;
	}

}
