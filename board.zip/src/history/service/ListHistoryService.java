package history.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import history.dao.MyHistoryDao;
import history.model.Rent;
import jdbc.connection.ConnectionProvider;

public class ListHistoryService {

	private MyHistoryDao myHistoryDao = new MyHistoryDao();
	private int size = 10;

	public HistoryPage getHistoryPage(String userId, int pageNum) {
		try (Connection conn = ConnectionProvider.getConnection()) {
			int total = myHistoryDao.selectCount(userId, conn);
			List<Rent> rent = myHistoryDao.select(userId,
					conn, (pageNum - 1) * size, size);
			return new HistoryPage(total, pageNum, size, rent);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
