package history.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import auth.service.User;
import history.service.HistoryPage;
import history.service.ListHistoryService;
import mvc.command.CommandHandler;

public class MyHistoryHandler implements CommandHandler {

	private ListHistoryService listService = new ListHistoryService();

	@Override
	public String process(HttpServletRequest req, HttpServletResponse res) 
			throws Exception {
		String pageNoVal = req.getParameter("pageNo");
		int pageNo = 1;
		if (pageNoVal != null) {
			pageNo = Integer.parseInt(pageNoVal);
		}
		User user = (User)req.getSession().getAttribute("authUser");
		
		HistoryPage historyPage = listService.getHistoryPage(user.getId(), pageNo);
		req.setAttribute("historyPage", historyPage);
		return "/WEB-INF/view/myHistory.jsp";
	}
	
	

}
