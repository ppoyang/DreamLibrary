package history.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import article.model.Article;
import article.model.ArticleContent;
import article.model.Writer;
import history.model.BookName;
import history.model.Rent;
import jdbc.JdbcUtil;

public class MyHistoryDao {
	

	private Timestamp toTimestamp(Date date) {
		return new Timestamp(date.getTime());
	}

	public int selectCount(String userId, Connection conn) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			
			pstmt = conn.prepareStatement("select count(*) from rent_tbl where user_id = ?");
			pstmt.setString(1, userId);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				return rs.getInt(1);
			}
			return 0;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	public List<Rent> select(String userId, Connection conn, int startRow, int size) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement("select * from rent_tbl where user_id = ? " +
					"order by article_no desc limit ?, ?");
			pstmt.setString(1, userId);
			pstmt.setInt(2, startRow);
			pstmt.setInt(3, size);
			rs = pstmt.executeQuery();
			List<Rent> result = new ArrayList<>();
			while (rs.next()) {
				result.add(convertRent(rs));
			}
			return result;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	private Rent convertRent(ResultSet rs) throws SQLException {

		return new Rent(rs.getString("rent_no"), rs.getString("user_id"),
				        rs.getString("book_id"), toDate(rs.getTimestamp("book_rent_date")),
				        toDate(rs.getTimestamp("book_re_due_date")),
				        toDate(rs.getTimestamp("book_re_date")),rs.getString("book_status"));
	}

	private Date toDate(Timestamp timestamp) {
		return new Date(timestamp.getTime());
	}
	
	public BookName selectById(Connection conn, String bookId) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(
					"select * from book_name where book_id = ?");
			pstmt.setString(1, bookId);
			rs = pstmt.executeQuery();
			BookName bookName = null;
			if (rs.next()) {
				bookName = new BookName(rs.getString("book_id"), rs.getString("book_name"));
			}
			return bookName;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}
}
