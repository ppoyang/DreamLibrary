package book.service;

public class ArticleNotFoundException extends RuntimeException {

}
