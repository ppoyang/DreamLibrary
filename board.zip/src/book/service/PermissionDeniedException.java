package book.service;

public class PermissionDeniedException extends RuntimeException {

}
