package book.service;

public class ArticleContentNotFoundException extends RuntimeException {

}
