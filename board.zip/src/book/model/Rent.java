package book.model;

import java.util.Date;

public class Rent {

	
	private String  rent_no;
	private String  user_id;
	private String  book_id;
	private Date    book_rent_date;
	private Date    book_re_due_date;
	private Date    book_re_date;
	private char    book_status;
	
	
	
	
	  
	public Rent(String rent_no, String user_id, String book_id, Date book_rent_date, Date book_re_due_date,
			Date book_re_date, char book_status) {
		super();
		this.rent_no = rent_no;
		this.user_id = user_id;
		this.book_id = book_id;
		this.book_rent_date = book_rent_date;
		this.book_re_due_date = book_re_due_date;
		this.book_re_date = book_re_date;
		this.book_status = book_status;
	}

	public String getRent_no() {
		return rent_no;
	}

	public String getUser_id() {
		return user_id;
	}

	public String getBook_id() {
		return book_id;
	}

	public Date getBook_rent_date() {
		return book_rent_date;
	}

	public Date getBook_re_due_date() {
		return book_re_due_date;
	}

	public Date getBook_re_date() {
		return book_re_date;
	}

	public char getBook_status() {
		return book_status;
	}

}
