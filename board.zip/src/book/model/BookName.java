package book.model;

public class BookName {

	private String book_id;
	private String book_name;

	public BookName(String book_id, String book_name) {
		this.book_id = book_id;
		this.book_name = book_name;
	}

	public String getBook_id() {
		return book_id;
	}

	public String getBook_name() {
		return book_name;
	}
	
}
