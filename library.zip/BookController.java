package com.wind.web;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.transaction.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wind.web.dao.SpecialtiesDao;
import com.wind.web.dao.VetsDao;
import com.wind.web.dao.VetspecialtiesDao;
import com.wind.web.dto.VetsDto;
import com.wind.web.dto.VetspecialtiesDto;

@Controller
public class BookController {

	@Autowired
	private SqlSession sqlSession;
	
	@Autowired
	private DataSourceTransactionManager transactionManager;
	
	@RequestMapping("/library/book_search")
	public String book_search() {
		return "/library/book_search";
	}
		
	@RequestMapping("/library/search_result")
	public String search_result(HttpServletRequest request, Model model) {
		VetsDao dao = sqlSession.getMapper(VetsDao.class);
		ArrayList<VetspecialtiesDto> dto;
		dto = dao.vetselectDao(Integer.parseInt(request.getParameter("specialty_id")));

		ArrayList<VetsDto> dto2 = new ArrayList<VetsDto>();
		for(int i=0;i<dto.size();i++) {
			dto2.add(dao.vetselect2Dao(dto.get(i).getVet_id()));
		}
		model.addAttribute("vetselect2", dto2);
		
		return "library/search_result";
	}
	
/*	
	@RequestMapping("/petclinic/vet_add_major")
	public String vet_add_major(Model model) {
		VetsDao dao1 = sqlSession.getMapper(VetsDao.class);
		SpecialtiesDao dao2 = sqlSession.getMapper(SpecialtiesDao.class);
		model.addAttribute("vetslist", dao1.vetslistDao());
		model.addAttribute("specialtieslist", dao2.specialtieslistDao());
		return "petclinic/vet_add_major";
	}
	
	@RequestMapping("/petclinic/vet_add_major_mod")
	public String vet_add_major_mod(HttpServletRequest request, Model model) throws Exception {
		String vet_id = request.getParameter("vet_id");
		String[] major = request.getParameterValues("major");
		
		// Spring Transaction - Reference Ch.10.6
		DefaultTransactionDefinition def = new DefaultTransactionDefinition();
//		def.setName("exam-tran");
//		def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		
		TransactionStatus status = transactionManager.getTransaction(def);

		try {
			del_vetspec(vet_id);
			for(int i=0;i<major.length;i++)  {
				add_vetspec(vet_id, major[i]);
			}
		transactionManager.commit(status);

		} catch (Exception e) {
			transactionManager.rollback(status);
			e.printStackTrace();
		}
		return "redirect:vetslist";
	}
	*/
	
	@ExceptionHandler
	public String handlerException(Exception e) {
		return "viewerror";
	}
	
}
